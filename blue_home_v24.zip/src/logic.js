/* ===== v11 布局逻辑 ===== */
var STAGE={w:1312,h:1199};
var AR=STAGE.w/STAGE.h;   /* 1.0942 */

/* 姿势：ratio=内容宽/高，ax=脚底中心在图内的水平比例，h=渲染高度(占舞台高) */
/* 走路三帧：a=左脚前, c=过渡, b=右脚前 —— 循环 a,c,b,c */
/* 三帧只提供 ratio/ax；高度统一取 girl 的 h，缩放才生效。
   ratio 保留真实值 —— C 帧是“腿并拢”的窄帧，强行统一宽度反而会让她走起来像企鹅。*/
var WALKF={
  a:{ratio:0.4355,ax:0.5110},
  b:{ratio:0.4211,ax:0.5110},   /* a/b 统一锚点，原来 0.5066/0.5155 差值会让脚底每帧漂 1% */
  c:{ratio:0.3132,ax:0.5018}
};
/* 过渡帧略高一点点，做出上下颠簸；单位：相对自身高度的 % */
var BOB={a:0,c:-1.5,b:0};
var SIT_K=0.726;
/* 每种姿势各记一份自己的大小：站、坐互不影响。
   否则坐姿乘 0.726、站姿不乘，来回切一次就得重新放大一次。*/
var GIRL_H0=0.270;
var girlH={stand:GIRL_H0, sit:+(GIRL_H0*SIT_K).toFixed(4)};
var WALK_MS=110;
var FLOOR_TOP=0.36;   /* 地板可视区上沿：低于此的不许放家具（花瓶 by=0.412 仍可放）*/

/* 透视缩放：以 by=0.72 为中性点 k=1，每 0.1 纵深差 4%；夹在 [0.86,1.14] */
var DEPTH_MID=0.87, DEPTH_SLOPE=0.35, DEPTH_LO=0.88, DEPTH_HI=1.10;
function depthK(by){
  var k=1+(by-DEPTH_MID)*DEPTH_SLOPE;
  return Math.max(DEPTH_LO,Math.min(DEPTH_HI,k));
}
var WALK_CYCLE=['a','c','b','c'];

var POSES={
  stand:{ratio:0.3553,ax:0.4619},
  sit:  {ratio:0.3789,ax:0.3550}
};

var ITEMS=[
 {id:'girl',    name:'小女孩', ratio:0.3671, ax:0.2986, cx:0.40,  by:0.870, h:0.270, min:0.08, max:1.40, solid:false},
 {id:'boy',     name:'我',     ratio:0.3277, ax:0.50,   cx:0.56,  by:0.900, h:0.282, min:0.08, max:1.40, solid:false},
 {id:'bed',     name:'床',     ratio:0.9671, ax:0.50,   cx:0.29,  by:0.735, h:0.355, min:0.06, max:1.40, solid:true},
 {id:'bedside', name:'床头柜', ratio:0.6099, ax:0.50,   cx:0.545, by:0.735, h:0.148, min:0.04, max:0.80, solid:true},
 {id:'wardrobe',name:'绿植',   ratio:0.9367, ax:0.50,   cx:0.848, by:0.585, h:0.400, min:0.06, max:1.40, solid:true},
 {id:'sofa',    name:'沙发',   ratio:1.3310, ax:0.50,   cx:0.665, by:0.870, h:0.235, min:0.05, max:1.20, solid:true},
 {id:'sideboard',name:'矮柜',  ratio:1.4206, ax:0.50,   cx:0.735, by:0.525, h:0.155, min:0.03, max:1.00, solid:true},
 {id:'vase',    name:'花瓶',   ratio:0.6421, ax:0.50,   cx:0.735, by:0.412, h:0.110, min:0.02, max:0.60, solid:true,  zBias:0.14, footFull:true},
 {id:'plant',   name:'衣柜',   ratio:0.5429, ax:0.50,   cx:0.922, by:0.965, h:0.290, min:0.05, max:1.40, solid:true},
 {id:'books',   name:'书本',   ratio:1.2422, ax:0.50,   cx:0.500, by:0.950, h:0.055, min:0.02, max:0.40, solid:false}
];

var state=[];
var girlPose='stand';

function widthFrac(h,ratio){return h*ratio/AR;}
/* 姿势已经折进 it.h 了，这里不再乘系数 */
function geomH(it){
  if(it.id==='girl'||it.id==='boy') return it.h*depthK(it.by);
  return it.h;   /* 家具尺寸由用户手调，不参与自动透视 */
}
function geomR(it){ if(it.id==='girl') return POSES[girlPose].ratio; return it.ratio; }
function geomA(it){ if(it.id==='girl') return POSES[girlPose].ax; return it.ax; }
function geomW(it){ return widthFrac(geomH(it),geomR(it)); }
/* 坐着时只要还压在沙发上，就永远画在沙发前面。
   否则人稍微往里（往上了）一挤，by 比沙发小，z-index 就掉到沙发背后，
   看起来就是腿和身子穿进沙发里。*/
function sofaItem(){var i;for(i=0;i<state.length;i++)if(state[i].id==='sofa')return state[i];return null;}
function sittingOnSofa(){
  if(girlPose!=='sit')return false;
  var g=null,s=sofaItem();
  var i;for(i=0;i<state.length;i++)if(state[i].id==='girl')g=state[i];
  if(!g||!s)return false;
  return Math.abs(g.cx-s.cx)<geomW(s)*0.62 && g.by>s.by-0.20 && g.by<s.by+0.30;
}
function zOf(it){
  if(it.id==='girl'&&sittingOnSofa())return sofaItem().by+0.02;
  return it.by+(it.zBias||0);
}

function footprint(it){
  var w=geomW(it), h=geomH(it);
  /* footFull：用整张立绘的占地做碰撞（花瓶这类细高的物件必须这样，
     否则只挡脚底一小块，人从旁边拖过去时身体会和花瓶图重叠，看着就是穿过去）*/
  if(it.footFull) return {x1:it.cx-w*0.5,x2:it.cx+w*0.5,y1:it.by-h,y2:it.by};
  var k=(it.footK!=null?it.footK:0.42);
  return {x1:it.cx-w*k,x2:it.cx+w*k,y1:it.by-h*0.30,y2:it.by-h*0.02};
}

function blockedAt(list,x,y,skip){
  var R=0.022,i,it,f;
  for(i=0;i<list.length;i++){
    it=list[i];
    if(it.id===skip||!it.solid)continue;
    f=footprint(it);
    if(x>f.x1-R&&x<f.x2+R&&y>f.y1-R*0.7&&y<f.y2+R*0.7)return it.id;
  }
  return null;
}

function landingFor(list,id){
  var t=null,i;
  for(i=0;i<list.length;i++){if(list[i].id===id)t=list[i];}
  if(!t)return null;
  var w=geomW(t);
  var spots=[
    [t.cx,t.by+0.055],[t.cx,t.by+0.105],
    [t.cx+w*0.60,t.by-0.010],[t.cx-w*0.60,t.by-0.010],
    [t.cx+w*0.70,t.by+0.055],[t.cx-w*0.70,t.by+0.055],
    [t.cx,t.by+0.165],[t.cx+w*0.52,t.by+0.130],[t.cx-w*0.52,t.by+0.130]
  ];
  for(i=0;i<spots.length;i++){
    var x=Math.max(0.05,Math.min(0.95,spots[i][0]));
    var y=Math.max(0.34,Math.min(0.97,spots[i][1]));
    if(!blockedAt(list,x,y,'girl'))return {x:x,y:y};
  }
  var r,ang,rad;
  for(r=0;r<10;r++){
    rad=0.07+r*0.05;
    for(ang=0;ang<16;ang++){
      var a=ang/16*Math.PI*2;
      var x2=Math.max(0.05,Math.min(0.95,t.cx+Math.cos(a)*rad));
      var y2=Math.max(0.34,Math.min(0.97,t.by+0.03+Math.sin(a)*rad*0.55));
      if(!blockedAt(list,x2,y2,'girl'))return {x:x2,y:y2};
    }
  }
  return null;
}

function segFree(list,a,b){
  var n=26,i,x,y;
  for(i=1;i<=n;i++){
    x=a.x+(b.x-a.x)*i/n;y=a.y+(b.y-a.y)*i/n;
    if(blockedAt(list,x,y,'girl'))return false;
  }
  return true;
}

/* ===== 网格寻路（v18）=====
   原来的 planPath 只有 4 条固定候选路线（直线、两个直角、两个下绕），
   全都不通的时候直接 return [mid2,to] —— 那一步就是“穿过家具走过去”。
   现在改成在舞台上铺一张 1.5% 的网格做 A*，走不通就真的走不通，
   由 walkTo 告诉用户“过不去”，而不是硬穿。                        */
var NAV_STEP=0.015, NAV_X0=0.02, NAV_X1=0.98, NAV_Y0=0.34, NAV_Y1=0.99;
function navCols(){ return Math.round((NAV_X1-NAV_X0)/NAV_STEP)+1; }
function navRows(){ return Math.round((NAV_Y1-NAV_Y0)/NAV_STEP)+1; }
function navXY(cx,cy){ return {x:NAV_X0+cx*NAV_STEP, y:NAV_Y0+cy*NAV_STEP}; }
function navCell(x,y){
  var cx=Math.round((x-NAV_X0)/NAV_STEP), cy=Math.round((y-NAV_Y0)/NAV_STEP);
  return {cx:Math.max(0,Math.min(navCols()-1,cx)), cy:Math.max(0,Math.min(navRows()-1,cy))};
}

/* 用线段把网格折线“拉直”：能直达就跳过中间点 */
function smoothPath(list,pts){
  if(pts.length<3)return pts;
  var out=[pts[0]], cur=0, n=pts.length;
  while(cur<n-1){
    var far=cur+1;
    for(var k=n-1;k>cur+1;k--){
      if(segFree(list,pts[cur],pts[k])){far=k;break;}
    }
    out.push(pts[far]);cur=far;
  }
  return out.slice(1);
}

function planPath(list,from,to){
  if(!to)return null;
  if(!from)return [to];
  if(segFree(list,from,to))return [to];

  var C=navCols(), R=navRows(), i, j, dx, dy;
  var occ=new Uint8Array(C*R);
  for(j=0;j<R;j++){
    for(i=0;i<C;i++){
      var pp=navXY(i,j);
      occ[j*C+i]=blockedAt(list,pp.x,pp.y,'girl')?1:0;
    }
  }
  var s=navCell(from.x,from.y), t=navCell(to.x,to.y);
  occ[s.cy*C+s.cx]=0; occ[t.cy*C+t.cx]=0;   /* 人就站在家具脚边时放行起终点 */

  var N=C*R, gScore=new Float32Array(N), fScore=new Float32Array(N);
  var came=new Int32Array(N), openFlag=new Uint8Array(N), closed=new Uint8Array(N);
  for(i=0;i<N;i++){gScore[i]=1e9;fScore[i]=1e9;came[i]=-1;}

  var start=s.cy*C+s.cx, goal=t.cy*C+t.cx;
  if(occ[start]||occ[goal])return null;

  function h(idx){
    var ax=idx%C, ay=(idx/C)|0;
    var ddx=Math.abs(ax-t.cx), ddy=Math.abs(ay-t.cy);
    return Math.max(ddx,ddy)+0.414*Math.min(ddx,ddy);
  }

  /* 小二叉堆，避免线性扫 open 表 */
  var heap=[start];
  gScore[start]=0; fScore[start]=h(start); openFlag[start]=1;
  function push(idx){
    heap.push(idx);
    var k=heap.length-1;
    while(k>0){
      var p=(k-1)>>1;
      if(fScore[heap[p]]<=fScore[heap[k]])break;
      var tmp=heap[p];heap[p]=heap[k];heap[k]=tmp;k=p;
    }
  }
  function pop(){
    var top=heap[0], last=heap.pop();
    if(heap.length){
      heap[0]=last;
      var k=0,n=heap.length;
      for(;;){
        var l=k*2+1, r=l+1, m=k;
        if(l<n&&fScore[heap[l]]<fScore[heap[m]])m=l;
        if(r<n&&fScore[heap[r]]<fScore[heap[m]])m=r;
        if(m===k)break;
        var tmp=heap[k];heap[k]=heap[m];heap[m]=tmp;k=m;
      }
    }
    return top;
  }

  var DIRS=[[1,0,1],[-1,0,1],[0,1,1],[0,-1,1],[1,1,1.414],[1,-1,1.414],[-1,1,1.414],[-1,-1,1.414]];
  var found=false, guard=0;
  while(heap.length&&guard++<20000){
    var cur=pop();
    if(cur===goal){found=true;break;}
    if(closed[cur])continue;
    closed[cur]=1;
    var cxx=cur%C, cyy=(cur/C)|0;
    for(var d=0;d<8;d++){
      var nx=cxx+DIRS[d][0], ny=cyy+DIRS[d][1];
      if(nx<0||ny<0||nx>=C||ny>=R)continue;
      var ni=ny*C+nx;
      if(occ[ni]||closed[ni])continue;
      /* 斜走不许穿角 */
      if(DIRS[d][2]>1&&(occ[cyy*C+nx]||occ[ny*C+cxx]))continue;
      var ng=gScore[cur]+DIRS[d][2];
      if(ng<gScore[ni]-1e-6){
        gScore[ni]=ng; came[ni]=cur; fScore[ni]=ng+h(ni);
        push(ni);
      }
    }
  }
  if(!found)return null;

  var cells=[], cc=goal;
  while(cc!==-1){cells.push(cc);if(cc===start)break;cc=came[cc];}
  cells.reverse();
  var pts=[];
  for(i=1;i<cells.length;i++){
    var v=navXY(cells[i]%C, (cells[i]/C)|0);
    pts.push(v);
  }
  /* 末点钉准 landing 坐标 */
  if(pts.length)pts[pts.length-1]={x:to.x,y:to.y};else pts=[to];
  return smoothPath(list,[from].concat(pts));
}

function clampItem(it,v){return Math.max(it.min,Math.min(it.max,v));}
